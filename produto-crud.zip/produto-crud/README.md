# Sistema de Gerenciamento de Produtos

Projeto Spring Boot com MVC para CRUD de produtos usando MySQL.

## Funcionalidades

- ✅ Cadastrar produtos
- ✅ Listar todos os produtos
- ✅ Atualizar produtos
- ✅ Excluir produtos
- ✅ Pesquisar produtos
- ✅ Filtrar por categoria

## Tecnologias

- Spring Boot 3.2.0
- Spring Data JPA
- Thymeleaf
- MySQL
- Bootstrap 5

## Configuração

1. Clone o repositório
2. Configure o MySQL com database `databasepi`
3. Altere as credenciais no `application.properties`
4. Execute a aplicação

## Endpoints

- `GET /produtos` - Lista todos os produtos
- `GET /produtos/novo` - Formulário de cadastro
- `POST /produtos/salvar` - Salva/atualiza produto
- `GET /produtos/editar/{id}` - Formulário de edição
- `GET /produtos/excluir/{id}` - Exclui produto
- `GET /produtos/pesquisar` - Pesquisa produtos

## Estrutura MVC

- **Model**: `Produto` (Entidade JPA)
- **View**: Templates Thymeleaf
- **Controller**: `ProdutoController`
- **Repository**: `ProdutoRepository` (Spring Data JPA)
- **Service**: `ProdutoService` (Lógica de negócio)