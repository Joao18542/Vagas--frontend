-- Arquivo: src/main/resources/data.sql
-- Este arquivo será executado automaticamente ao iniciar a aplicação

INSERT IGNORE INTO produtos (nome, descricao, preco, quantidade, categoria) VALUES
('Smartphone Samsung', 'Smartphone Android com 128GB', 899.99, 50, 'Eletrônicos'),
('Notebook Dell', 'Notebook i5 8GB RAM 256GB SSD', 2499.99, 25, 'Eletrônicos'),
('Camiseta Nike', 'Camiseta dry fit esportiva', 79.90, 100, 'Roupas'),
('Livro Spring Boot', 'Guia completo de Spring Boot', 89.90, 30, 'Livros'),
('Mouse Logitech', 'Mouse sem fio ergonômico', 129.90, 75, 'Eletrônicos');