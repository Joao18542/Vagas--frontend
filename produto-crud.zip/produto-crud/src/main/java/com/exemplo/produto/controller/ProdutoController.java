package com.exemplo.produto.controller;

import com.exemplo.produto.model.Produto;
import com.exemplo.produto.service.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/produtos")
public class ProdutoController {
    
    @Autowired
    private ProdutoService produtoService;
    
    // Página inicial - Listar todos os produtos
    @GetMapping
    public String listarProdutos(Model model) {
        List<Produto> produtos = produtoService.listarTodos();
        model.addAttribute("produtos", produtos);
        model.addAttribute("produto", new Produto());
        return "produtos/listar";
    }
    
    // Formulário de cadastro
    @GetMapping("/novo")
    public String mostrarFormularioCadastro(Model model) {
        model.addAttribute("produto", new Produto());
        return "produtos/formulario";
    }
    
    // Salvar produto (CREATE)
    @PostMapping("/salvar")
    public String salvarProduto(@ModelAttribute Produto produto) {
        produtoService.salvar(produto);
        return "redirect:/produtos";
    }
    
    // Formulário de edição (UPDATE)
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicao(@PathVariable Long id, Model model) {
        Optional<Produto> produto = produtoService.buscarPorId(id);
        if (produto.isPresent()) {
            model.addAttribute("produto", produto.get());
            return "produtos/formulario";
        }
        return "redirect:/produtos";
    }
    
    // Excluir produto (DELETE)
    @GetMapping("/excluir/{id}")
    public String excluirProduto(@PathVariable Long id) {
        produtoService.excluir(id);
        return "redirect:/produtos";
    }
    
    // Pesquisar produtos
    @GetMapping("/pesquisar")
    public String pesquisarProdutos(@RequestParam String termo, Model model) {
        List<Produto> produtos = produtoService.pesquisar(termo);
        model.addAttribute("produtos", produtos);
        model.addAttribute("produto", new Produto());
        model.addAttribute("termoPesquisa", termo);
        return "produtos/listar";
    }
    
    // Buscar por categoria
    @GetMapping("/categoria/{categoria}")
    public String buscarPorCategoria(@PathVariable String categoria, Model model) {
        List<Produto> produtos = produtoService.buscarPorCategoria(categoria);
        model.addAttribute("produtos", produtos);
        model.addAttribute("produto", new Produto());
        model.addAttribute("categoriaSelecionada", categoria);
        return "produtos/listar";
    }
}