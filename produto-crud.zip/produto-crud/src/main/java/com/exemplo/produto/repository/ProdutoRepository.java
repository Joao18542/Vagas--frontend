package com.exemplo.produto.repository;

import com.exemplo.produto.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProdutoRepository extends JpaRepository<Produto, Long> {
    
    // Buscar produtos por nome (pesquisa)
    List<Produto> findByNomeContainingIgnoreCase(String nome);
    
    // Buscar produtos por categoria
    List<Produto> findByCategoriaContainingIgnoreCase(String categoria);
    
    // Buscar produtos com preço menor ou igual
    List<Produto> findByPrecoLessThanEqual(Double preco);
    
    // Query personalizada para busca geral
    @Query("SELECT p FROM Produto p WHERE " +
           "LOWER(p.nome) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
           "LOWER(p.descricao) LIKE LOWER(CONCAT('%', :termo, '%')) OR " +
           "LOWER(p.categoria) LIKE LOWER(CONCAT('%', :termo, '%'))")
    List<Produto> pesquisar(@Param("termo") String termo);
}