package com.exemplo.produto.service;

import com.exemplo.produto.model.Produto;
import com.exemplo.produto.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {
    
    @Autowired
    private ProdutoRepository produtoRepository;
    
    // Salvar ou atualizar produto
    public Produto salvar(Produto produto) {
        return produtoRepository.save(produto);
    }
    
    // Listar todos os produtos
    public List<Produto> listarTodos() {
        return produtoRepository.findAll();
    }
    
    // Buscar produto por ID
    public Optional<Produto> buscarPorId(Long id) {
        return produtoRepository.findById(id);
    }
    
    // Excluir produto
    public void excluir(Long id) {
        produtoRepository.deleteById(id);
    }
    
    // Pesquisar produtos por termo
    public List<Produto> pesquisar(String termo) {
        return produtoRepository.pesquisar(termo);
    }
    
    // Buscar por nome
    public List<Produto> buscarPorNome(String nome) {
        return produtoRepository.findByNomeContainingIgnoreCase(nome);
    }
    
    // Buscar por categoria
    public List<Produto> buscarPorCategoria(String categoria) {
        return produtoRepository.findByCategoriaContainingIgnoreCase(categoria);
    }
}